// import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import ProductP from "./pages/ProductP";
// import ProductList from "./pages/ProductList";


const App = () => {
  return <Home/>;
  
};

export default App;