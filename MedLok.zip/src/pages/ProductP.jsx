// import { Filter } from '@material-ui/icons';
import styled from 'styled-components'
import Announcement from '../components/Announcement';
import Footer from '../components/Footer';
import Navbar from '../components/Navbar';
import Newsletter from '../components/Newsletter';

const Container = styled.div`

`;

const Wrapper = styled.div`
    padding: 50px;
    display: flex;
`;

const ImgContainer = styled.div`
    flex: 1;
`;

const Image = styled.img`
    width: 100%;
    height: 60vh;
    object-fit: cover;
`;

const InfoContainer = styled.div`
    flex: 1;
    padding: 0px 50px;
`;

const Title = styled.h1`
    font-weight: 300;
`;

const Desc = styled.p`
    margin: 20px 0px;
`;

const Price = styled.span`
    font-weight: 200;
    font-size: 40px;
`;

const ProductP = () => {
    return (
        <Container>
            <Navbar/>
            <Announcement/>
            <Wrapper>
                <ImgContainer>
                    <Image src="https://images.pexels.com/photos/7230192/pexels-photo-7230192.jpeg"></Image>
                </ImgContainer>
                <InfoContainer>
                    <Title>levothyroxine</Title>
                    <Desc>Levothyroxine is a thyroid medicine that replaces a hormone normally produced by your thyroid gland to regulate the body's energy and metabolism. Levothyroxine is used to treat hypothyroidism (low thyroid hormone). </Desc>
                    <Price>$ 50</Price>
                    {/* <FilterContainer>
                        <Filter>
                            <FilterTitle>
                                Dose
                            </FilterTitle>
                            <FilterTitle>
                                500-700mg
                            </FilterTitle>
                            <FilterTitle>
                                100-500mg
                            </FilterTitle>
                        </Filter>
                    </FilterContainer> */}
                </InfoContainer>
            </Wrapper>
            <Newsletter/>
            {/* <Products/> */}
            <Footer/>
        </Container>
    )
}

export default ProductP
